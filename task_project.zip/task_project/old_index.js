// const mongo = require("mongoose")
// const express = require('express')
// const app = express()
// const port = 8787;
//
// const cors = require('cors');
// app.use(cors());
//
// app.set('view engine', 'ejs')
// app.set('views', './templates')
// app.use(express.json());
// app.use(express.urlencoded({extended: true}));
//
// mongo.connect('mongodb+srv://rysbekdossayev:Laravel5@cluster0.guazwsy.mongodb.net/?retryWrites=true&w=majority', {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
// })
//     .then(() => console.log("Соединение с базой данных установлено"))
//     .catch(err => console.error("Ошибка подключения к базе данных:", err));
//
// const bookSchema = new mongo.Schema({
//     name: String,
//     description:String,
//     ganre:String,
//     author: {},
//
// });
// const AuthorSchema = new mongo.Schema({
//     name: String,
//     surname: String,
//     country: String,
// });
//
// const UserSchema = new mongo.Schema({
//     email: String,
//     firstname: String,
//     password: String ,
// })
//
//
//
// const Book = mongo.model('Book',bookSchema );
// const Author = mongo.model('Author',AuthorSchema )
// const User = mongo.model('User',UserSchema )
//
// app.get('/', async (req, res) => {
//     try {
//         const books = await Book.find({}).exec();
//         res.render('index', { test: 12455, book_list: books });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Ошибка загрузки books');
//     }
// })
//
//
// app.get('/create/book', async (req, res) => {
//
//     const authors = await Author.find({}).exec();
//     res.render('book_create', {authors:authors})
// })
// app.get('/create/author', (req, res) => {
//     res.render('author_create')
// })
// app.post('/save/book', async (req, res) => {
//     const name = req.body.name;
//     const ganre = req.body.ganre;
//     const description = req.body.description
//
//
//     const author = await Author.find({_id :req.body.author}).exec();
//     try {
//         const testData = {name, ganre, description,author}
//         const newUser = new Book(testData);
//         await newUser.save();
//         console.log('Book успешно добавлен');
//         res.redirect('/');
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Ошибка сохранения Book');
//     }
//
// });
// app.post('/save/author', async (req, res) => {
//     const name = req.body.name;
//     const surname = req.body.surname;
//     const country = req.body.country
//     const testData = {name, surname, country}
//
//     try {
//         const newUser = new Author(testData);
//         await newUser.save();
//         console.log('author успешно добавлен');
//         res.redirect('/');
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Ошибка сохранения author');
//     }
//
// });
//
// app.get('/update-book/:id', async (req, res) => {
//
//     try {
//         let bookId = req.params.id;
//         const book = await Book.findById(bookId);
//         if (!book) {
//             return res.status(404).send('Book не найден');
//         }
//         res.render('book_edit',{ book: book })
//
//
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('not found  book');
//     }
// });
//
// app.post('/update-book/:id', async (req, res) => {
//     const bookId = req.params.id;
//     const updatedData = req.body;
//     try {
//         // Используем метод findByIdAndUpdate для обновления данных студента
//         const updatedBook = await Book.findByIdAndUpdate(bookId, updatedData, { new: true });
//
//         if (!updatedBook) {
//             return res.status(404).send('book не найден');
//         }
//         res.redirect('/update-book/'+bookId);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Ошибка при обновлении студента');
//     }
// });
//
//
// // api
// app.get('/api/books', async (req, res) => {
//     try {
//         const books = await Book.find({}).exec();
//         return res.status(200).json({
//             status: true,
//             data: books,
//         });
//         // return res.json(books);
//     } catch (err) {
//         return res.status(500).json({
//             status: false,
//             error: err,
//         });
//     }
// })
// app.get('/api/books/:id', async (req, res) => {
//     try {
//         const book = await Book.findById(req.params.id).exec();
//         if (!book) {
//             return res.status(404).send('Book не найден');
//         }
//         return res.status(200).json({
//           book
//         });
//     } catch (err) {
//         console.error(err);
//         return res.status(500).json({
//             status: false,
//             error: err,
//         });
//     }
// })
// app.post('/api/books', async (req, res) => {
//     const name = req.body.name;
//     const ganre = req.body.ganre;
//     const description = req.body.description
//     let author = req.body.author_id
//     author = await Author.findOne({_id :author}).exec();
//     if (!author || !author._id || !name) {
//         return res.status(500).json({
//             status: false,
//             error: 'Не указаны все данные',
//         });
//     }
//     const testData = {name, ganre, description,author}
//     try {
//         const newUser = new Book(testData);
//         await newUser.save();
//         console.log('Book успешно добавлен');
//         return res.status(200).json({
//             status: true,
//             data: newUser,
//         });
//         // return res.json(newUser);
//     } catch (err) {
//         console.error(err);
//         return res.status(500).json({
//             status: false,
//             error: 'Ошибка сохранения Book',
//         });
//     }
// })
// app.get('/api/authors', async (req, res) => {
//     try {
//         const authors = await Author.find({}).exec();
//         return res.status(200).json({
//             status: true,
//             data: authors,
//         });
//     } catch (err) {
//         return res.status(500).json({
//             status: false,
//             error: 'Ошибка загрузки authors',
//         });
//     }
// })
// app.get('/api/openapi/items', async (req, res) => {
//     try {
//         if (req.body.page){
//
//             const users = await fetch('https://jsonplaceholder.typicode.com/users?page='+req.body.page).then(response => response.json())
//             return res.status(200).json({
//                 status: true,
//                 data: users,
//             });
//         }
//        const users = await fetch('https://jsonplaceholder.typicode.com/users').then(response => response.json())
//         return res.status(200).json({
//             status: true,
//             data: users,
//         });
//     } catch (err) {
//         return res.status(500).json({
//             status: false,
//             error: 'Ошибка загрузки authors',
//         });
//     }
// })
//
// app.post('/api/register', async (req, res) => {
//
//     console.log(req.body)
//     const email = req.body.email;
//     const firstname = req.body.firstname;
//     const password = req.body.password;
//     if (!email || !firstname || !password) {
//         return res.status(500).json({
//             status: false,
//             error: 'Не указаны все данные',
//         });
//     }
//     const testData = {email, firstname, password}
//     try {
//         const newUser = new User(testData);
//         await newUser.save();
//         console.log('User успешно добавлен');
//         return res.status(200).json({
//             status: true,
//             data: newUser,
//         });
//         // return res.json(newUser);
//     } catch (err) {
//         console.error(err);
//         return res.status(500).json({
//             status: false,
//             error: 'Ошибка сохранения User',
//         });
//     }
// })
//
// app.get('/api/users', async (req, res) => {
//
//     try {
//         const users = await User.find({}).exec();
//         return res.status(200).json({
//             status: true,
//             data: users,
//         });
//     } catch (err) {
//         return res.status(500).json({
//             status: false,
//             error: 'Ошибка загрузки users',
//         });
//     }
// })
//
//
// app.listen(port, () => {
//
// })