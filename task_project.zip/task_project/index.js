const mongo = require("mongoose")
const express = require('express')
const app = express()
const port = 8787;
const User = require('./models/user');

const cors = require('cors');

app.use(cors());

app.set('view engine', 'ejs')
app.set('views', './templates')
app.use(express.json());
app.use(express.urlencoded({extended: true}));

mongo.connect('mongodb+srv://rysbekdossayev:Laravel5@cluster0.guazwsy.mongodb.net/?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log("Соединение с базой данных установлено"))
    .catch(err => console.error("Ошибка подключения к базе данных:", err));

const TaskSchema = new mongo.Schema({
    name: String,
    description: String,
    isCompleted: Boolean,
    date: Date
});

const Task = mongo.model('Task', TaskSchema);

app.get('/api/tasks', async (req, res) => {
    try {
        const tasks = await Task.find({}).exec();
        return res.status(200).json({
            status: true,
            data: tasks,
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            error: err,
        });
    }
})
app.post('/api/tasks', async (req, res) => {

    let {name, description, isCompleted, date} = req.body;
    date = date ? new Date(date) : new Date();
    const task = new Task({
        name,
        description,
        isCompleted,
        date,
    });
    try {
        await task.save();
        return res.status(200).json({
            status: true,
            data: task,
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            error: err,
        });
    }
});
app.get('/api/tasks/:id', async (req, res) => {
    const {id} = req.params;
    try {
        const task = await Task.findById(id).exec();

        if (!task) {
            return res.status(404).json({
                status: false,
                error: 'Task not found',
            });
        }
        return res.status(200).json({
            status: true,
            data: task,
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            error: err,
        });
    }
});

app.put('/api/tasks/:id', async (req, res) => {
    const {id} = req.params;
    const {name, description, isCompleted, date} = req.body;
    try {
        const task = await Task
            .findByIdAndUpdate(id, {name, description, isCompleted, date}, {new: true})
            .exec();

        if (!task) {
            return res.status(404).json({
                status: false,
                error: 'Task not found',
            });
        }
        return res.status(200).json({
            status: true,
            data: task,
        });

    } catch (err) {
        return res.status(500).json({
            status: false,
            error: err,
        });
    }
});

app.delete('/api/tasks/:id', async (req, res) => {
    const {id} = req.params;
    try {
        const task = await Task.findByIdAndDelete(id).exec();
        if (!task) {
            return res.status(404).json({
                status: false,
                error: 'Task not found',
            });
        }
        return res.status(200).json({
            status: true,
            data: task,
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            error: err,
        });
    }
})
// #################################---------USER----------#######################################
app.post('/api/register', async (req, res) => {
    try {
        const user = new User({
            username: req.body.username,
            title: req.body.title,
            firstName: req.body.firstName,
            lastname: req.body.lastname,
        });
        await User.register(user, req.body.password);

        return res.status(200).json({
            status: true,
            data: user,
        });
    } catch (e) {
        return res.status(500).json({
            status: false,
            error: e,
        });
    }
});

app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find({}).exec();
        return res.status(200).json({
            status: true,
            data: users,
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            error: err,
        });
    }
})

app.listen(port, () => {
})